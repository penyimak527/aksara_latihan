<style>
	.detail-siswa-page {
		--ls-blue: #2f6df6;
		--ls-orange: #f59e0b;
		--ls-green: #10b981;
		--ls-purple: #8b5cf6;
		--ls-cyan: #06b6d4;
		--ls-pink: #ec4899;
		--ls-soft-border: #e8eef6;
		--ls-text: #1f2937;
		--ls-muted: #7b8794;
	}

	.detail-topbar {
		background: transparent;
		border: 0;
		box-shadow: none;
		margin-bottom: 12px;
	}

	.detail-topbar .card-body {
		padding: 4px 0 8px 0;
	}

	.back-round {
		width: 34px;
		height: 34px;
		border-radius: 50%;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		border: 0;
		background: rgba(15, 23, 42, .04);
		color: #334155;
		font-size: 18px;
		text-decoration: none;
	}

	.student-name-title {
		font-size: 20px;
		font-weight: 800;
		line-height: 1.2;
		margin: 0;
		color: var(--ls-text);
	}

	.student-subtitle {
		font-size: 13px;
		color: var(--ls-muted);
		margin-top: 3px;
	}

	.summary-grid {
		display: grid;
		grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
		gap: 14px;
		align-items: stretch;
	}

	.summary-card {
		border: 0;
		border-radius: 8px;
		padding: 16px 18px;
		min-height: 104px;
		color: #fff;
		display: flex;
		align-items: center;
		gap: 14px;
		box-shadow: 0 8px 20px rgba(15, 23, 42, .10);
		overflow: hidden;
		width: 100%;
	}

	.summary-icon {
		width: 44px;
		height: 44px;
		border-radius: 12px;
		background: rgba(255, 255, 255, .22);
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 20px;
		font-weight: 700;
		flex: 0 0 44px;
	}

	.summary-content {
		min-width: 0;
		flex: 1 1 auto;
	}

	.summary-label {
		font-size: 13px;
		line-height: 1.25;
		font-weight: 700;
		opacity: .92;
		white-space: normal;
		overflow: visible;
		text-overflow: initial;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}

	.summary-value {
		font-size: 28px;
		font-weight: 900;
		line-height: 1;
		margin-top: 6px;
	}

	.summary-blue { background: linear-gradient(135deg, #2563eb, #3b82f6); }
	.summary-orange { background: linear-gradient(135deg, #f97316, #facc15); }
	.summary-green { background: linear-gradient(135deg, #10b981, #22c55e); }
	.summary-purple { background: linear-gradient(135deg, #7c3aed, #a78bfa); }
	.summary-cyan { background: linear-gradient(135deg, #0891b2, #22d3ee); }
	.summary-pink { background: linear-gradient(135deg, #db2777, #fb7185); }

	.panel-card {
		border: 1px solid var(--ls-soft-border);
		border-radius: 8px;
		box-shadow: 0 6px 18px rgba(15, 23, 42, .04);
	}

	.panel-card .card-body {
		padding: 16px;
	}

	.panel-title {
		font-size: 17px;
		font-weight: 800;
		margin-bottom: 14px;
		color: var(--ls-text);
	}

	.history-list {
		max-height: 640px;
		overflow-y: auto;
		padding-right: 4px;
	}

	.history-item {
		border: 1px solid transparent;
		background: #f5f7fb;
		border-radius: 12px;
		padding: 12px;
		margin-bottom: 10px;
		cursor: pointer;
		transition: .18s ease;
	}

	.history-item:hover {
		border-color: #38bdf8;
		background: #eff9ff;
	}

	.history-item.active {
		border-color: #38bdf8;
		background: #e8f7ff;
		box-shadow: inset 0 0 0 1px #38bdf8;
	}

	.history-title {
		font-size: 14px;
		font-weight: 800;
		color: var(--ls-text);
		margin: 0 0 4px;
	}

	.history-meta {
		font-size: 12px;
		color: var(--ls-muted);
		line-height: 1.35;
	}

	.history-score {
		font-size: 14px;
		font-weight: 800;
		color: #10b981;
		white-space: nowrap;
	}

	.session-head {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: 12px;
		margin-bottom: 12px;
	}

	.session-title {
		font-size: 17px;
		font-weight: 800;
		margin: 0;
		color: var(--ls-text);
	}

	.session-mapel {
		font-size: 13px;
		color: var(--ls-muted);
		margin-top: 2px;
	}

	.session-score {
		font-size: 28px;
		font-weight: 900;
		line-height: 1;
		color: #10b981;
		text-align: right;
	}

	.session-score small {
		display: block;
		font-size: 12px;
		font-weight: 600;
		color: var(--ls-muted);
		margin-top: 6px;
	}

	.session-info {
		display: flex;
		flex-wrap: wrap;
		gap: 8px;
		margin-bottom: 12px;
	}

	.info-chip {
		font-size: 12px;
		border-radius: 999px;
		padding: 6px 10px;
		background: #f3f6fa;
		color: #475569;
	}

	.topic-box {
		border-radius: 12px;
		padding: 14px;
		margin-bottom: 14px;
	}

	.topic-box.success {
		background: #eafaf3;
	}

	.topic-box.warning {
		background: #fff8e6;
	}

	.topic-box-title {
		font-size: 16px;
		font-weight: 800;
		margin-bottom: 10px;
	}

	.topic-box.success .topic-box-title {
		color: #047857;
	}

	.topic-box.warning .topic-box-title {
		color: #92400e;
	}

	.topic-row {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 10px;
		padding: 6px 0;
		font-size: 13px;
	}

	.topic-name {
		color: #374151;
		font-weight: 600;
	}

	.topic-count {
		font-size: 12px;
		color: #64748b;
		white-space: nowrap;
	}

	.topic-pill {
		font-size: 12px;
		font-weight: 800;
		border-radius: 999px;
		padding: 4px 8px;
		min-width: 52px;
		text-align: center;
		white-space: nowrap;
	}

	.pill-good { background: #d1fae5; color: #059669; }
	.pill-mid { background: #fef3c7; color: #d97706; }
	.pill-low { background: #fee2e2; color: #dc2626; }

	.all-topic-row {
		display: grid;
		grid-template-columns: 1fr 120px 54px;
		align-items: center;
		gap: 12px;
		padding: 7px 0;
		font-size: 13px;
	}

	.all-topic-name {
		font-weight: 600;
		color: #374151;
	}

	.progress-mini {
		height: 7px;
		border-radius: 99px;
		background: #eef2f7;
		overflow: hidden;
	}

	.progress-mini span {
		display: block;
		height: 100%;
		border-radius: 99px;
		background: #10b981;
	}

	.progress-mini.mid span { background: #f59e0b; }
	.progress-mini.low span { background: #ef4444; }

	.preview-card {
		border: 1px solid var(--ls-soft-border);
		border-radius: 12px;
		padding: 12px;
		margin-bottom: 12px;
		background: #fff;
	}

	.preview-modal-body {
		background: #f8fafc;
	}

	.preview-question-card {
		border: 1px solid var(--ls-soft-border);
		border-radius: 14px;
		background: #fff;
		padding: 14px;
		margin-bottom: 14px;
		box-shadow: 0 4px 12px rgba(15, 23, 42, .04);
	}

	.preview-question-head {
		display: flex;
		align-items: flex-start;
		justify-content: space-between;
		gap: 10px;
		margin-bottom: 10px;
	}

	.preview-no {
		width: 34px;
		height: 34px;
		border-radius: 10px;
		background: #eff6ff;
		color: #2563eb;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		font-weight: 900;
		flex: 0 0 34px;
	}

	.preview-title {
		font-size: 15px;
		font-weight: 800;
		color: var(--ls-text);
		margin: 0;
	}

	.preview-subtitle {
		font-size: 12px;
		color: var(--ls-muted);
		margin-top: 2px;
	}

	.preview-badge {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		border-radius: 999px;
		padding: 5px 10px;
		font-size: 12px;
		font-weight: 800;
		white-space: nowrap;
	}

	.preview-badge.benar {
		background: #d1fae5;
		color: #047857;
	}

	.preview-badge.sebagian {
		background: #fef3c7;
		color: #b45309;
	}

	.preview-badge.salah {
		background: #fee2e2;
		color: #b91c1c;
	}

	.preview-section {
		border: 1px solid #edf2f7;
		border-radius: 12px;
		background: #fbfdff;
		padding: 12px;
		margin-top: 10px;
	}

	.preview-label {
		font-size: 12px;
		font-weight: 800;
		color: #64748b;
		text-transform: uppercase;
		letter-spacing: .02em;
		margin-bottom: 5px;
	}

	.preview-text {
		font-size: 14px;
		color: #1f2937;
		line-height: 1.55;
		white-space: pre-wrap;
		word-break: break-word;
	}

	.preview-answer-grid {
		display: grid;
		grid-template-columns: repeat(2, minmax(0, 1fr));
		gap: 10px;
		margin-top: 10px;
	}

	.preview-answer-box {
		border-radius: 12px;
		padding: 12px;
		border: 1px solid #e5eaf2;
		background: #fff;
		min-height: 82px;
	}

	.preview-answer-box.student-answer {
		border-left: 4px solid #3b82f6;
	}

	.preview-answer-box.correct-answer {
		border-left: 4px solid #10b981;
	}

	.preview-score-row {
		display: flex;
		align-items: center;
		justify-content: space-between;
		gap: 10px;
		border-top: 1px dashed #e5eaf2;
		margin-top: 12px;
		padding-top: 10px;
	}

	.preview-score {
		font-size: 15px;
		font-weight: 900;
		color: #10b981;
	}

	.preview-total-box {
		position: sticky;
		bottom: 0;
		border-top: 1px solid #e5eaf2;
		background: #fff;
		padding: 12px 16px;
		box-shadow: 0 -8px 18px rgba(15, 23, 42, .06);
	}

	.preview-total-label {
		font-size: 13px;
		font-weight: 800;
		color: #64748b;
	}

	.preview-total-value {
		font-size: 22px;
		font-weight: 900;
		color: #10b981;
		line-height: 1;
	}

	.empty-state {
		border: 1px dashed #d7dee8;
		border-radius: 12px;
		padding: 14px;
		color: #7b8794;
		font-size: 13px;
		background: #fafcff;
	}

	@media (max-width: 991px) {
		.history-list {
			max-height: none;
		}
	}

	@media (max-width: 575px) {
		.summary-grid {
			grid-template-columns: 1fr;
			gap: 10px;
		}

		.summary-card {
			min-height: 86px;
			padding: 12px 14px;
		}

		.summary-icon {
			width: 38px;
			height: 38px;
			flex-basis: 38px;
		}

		.summary-value {
			font-size: 24px;
		}

		.session-score {
			font-size: 24px;
		}

		.all-topic-row {
			grid-template-columns: 1fr 70px 46px;
			gap: 8px;
		}

		.preview-answer-grid {
			grid-template-columns: 1fr;
		}

		.preview-question-head {
			align-items: flex-start;
		}

		.preview-total-box {
			position: static;
		}
	}
</style>

<div class="detail-siswa-page">
	<div class="card detail-topbar">
		<div class="card-body" id="header-siswa">
			<div class="d-flex align-items-center gap-2">
				<a href="<?= base_url('latihan_soal/analisa_kelas'); ?>" class="back-round" title="Kembali">←</a>
				<div>
					<h4 class="student-name-title">Memuat detail siswa...</h4>
					<div class="student-subtitle">Mohon tunggu sebentar</div>
				</div>
			</div>
		</div>
	</div>

	<div id="area-detail" style="display:none;">
		<div class="card panel-card mb-3">
			<div class="card-body">
				<div class="row g-2 align-items-center">
					<div class="col-md-7">
						<h4 class="panel-title mb-1">Ringkasan Nilai</h4>
						<div class="student-subtitle">Pilih mata pelajaran untuk melihat rata-rata mapel dan riwayat ujian terkait.</div>
					</div>
					<div class="col-md-5">
						<label class="form-label mb-1">Mata Pelajaran</label>
						<select class="form-select" id="filter-mapel-detail">
							<option value="">Memuat mata pelajaran...</option>
						</select>
					</div>
				</div>

				<div class="summary-grid mt-3" id="ringkasan-siswa"></div>
			</div>
		</div>

		<div class="row g-3">
			<div class="col-lg-4">
				<div class="card panel-card">
					<div class="card-body">
						<h4 class="panel-title">Riwayat Ujian</h4>
						<div id="riwayat-pengerjaan" class="history-list"></div>
					</div>
				</div>
			</div>

			<div class="col-lg-8">
				<div class="card panel-card mb-3">
					<div class="card-body" id="detail-sesi">
						<div class="empty-state">Pilih salah satu riwayat untuk melihat analisa sesi.</div>
					</div>
				</div>

				<div class="card panel-card mb-3">
					<div class="card-body" id="analisa-materi-siswa">
						<div class="empty-state">Analisa materi belum tersedia.</div>
					</div>
				</div>

				<div class="card panel-card mb-3">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between gap-2 flex-wrap">
							<div>
								<h4 class="panel-title mb-1">Preview Jawaban</h4>
								<div class="student-subtitle">Klik tombol untuk melihat detail soal dan jawaban dalam modal.</div>
							</div>
							<button type="button" class="btn btn-sm btn-outline-primary" id="btn-preview">Preview Jawaban</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade" id="modal-preview-jawaban" tabindex="-1" aria-labelledby="modal-preview-jawaban-label" aria-hidden="true">
	<div class="modal-dialog modal-xl modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header">
				<div>
					<h5 class="modal-title" id="modal-preview-jawaban-label">Preview Jawaban</h5>
					<div class="student-subtitle mb-0" id="preview-modal-subtitle">Detail soal, jawaban siswa, kunci jawaban, status, dan nilai.</div>
				</div>
				<button type="button" class="btn-close" data-bs-dismiss="modal" data-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body preview-modal-body" id="preview-jawaban-modal-body">
				<div class="empty-state">Belum ada preview jawaban.</div>
			</div>
			<div class="preview-total-box">
				<div class="d-flex align-items-center justify-content-between gap-2">
					<div class="preview-total-label">Total Nilai</div>
					<div class="preview-total-value" id="preview-total-nilai">-</div>
				</div>
			</div>
			<div class=" modal-footer">
				<button type="button" class="btn btn-light" data-bs-dismiss="modal">Tutup</button>
			</div>
		</div>
	</div>
</div>

<script>
	const pageInfo = <?= json_encode($page); ?>;
	let currentDetail = null;
	let selectedMapelId = 0;

	$(document).ready(function () {
		detailSiswa(pageInfo.id_pengerjaan || 0);

		$('#btn-preview').on('click', function () {
			showPreviewModal();
		});

		$(document).on('change', '#filter-mapel-detail', function () {
			selectedMapelId = $(this).val() || 0;
			detailSiswa(0);
		});
	});

	function escapeHtml(text) {
		return $('<div/>').text(text ?? '').html();
	}

	function percentNumber(value) {
		let n = parseFloat(String(value ?? '0').replace('%', '').replace(',', '.'));
		return isNaN(n) ? 0 : n;
	}

	function colorByPercent(value) {
		let n = percentNumber(value);
		if (n >= 80) return 'good';
		if (n >= 60) return 'mid';
		return 'low';
	}

	function summaryColor(index) {
		const colors = ['summary-blue', 'summary-orange', 'summary-green', 'summary-purple', 'summary-cyan', 'summary-pink'];
		return colors[index % colors.length];
	}

	function shortMapelName(name) {
		name = String(name || '-');
		if (name.toLowerCase().indexOf('bahasa indonesia') !== -1) return 'B. Indonesia';
		if (name.toLowerCase().indexOf('bahasa inggris') !== -1) return 'B. Inggris';
		return name;
	}

	function detailSiswa(idPengerjaan) {
		$.ajax({
			url: '<?= base_url('latihan_soal/detail_siswa/detail_result'); ?>',
			type: 'POST',
			dataType: 'JSON',
			data: {
				id_siswa: pageInfo.id_siswa,
				tahun_ajaran: pageInfo.tahun_ajaran,
				id_kelas: pageInfo.id_kelas,
				id_pengerjaan: idPengerjaan || 0,
				id_mata_pelajaran: selectedMapelId || 0
			},
			success: function (res) {
				if (res.result != 'true') {
					$('#header-siswa').html(`<div class="alert alert-warning mb-0">${escapeHtml(res.message || 'Data tidak ditemukan.')}</div>`);
					$('#area-detail').hide();
					return;
				}

				currentDetail = res;
				selectedMapelId = res.filter && res.filter.id_mata_pelajaran ? res.filter.id_mata_pelajaran : selectedMapelId;

				$('#area-detail').show();
				renderHeader(res.siswa, res.ringkasan);
				renderMapelOptions(res.mapel_options || [], selectedMapelId);
				renderRingkasan(res.ringkasan);
				renderRiwayat(res.riwayat, res.id_pengerjaan_aktif);
				renderDetailSesi(res.detail_sesi);
				renderMateri(res.materi);
				renderPreview(res.preview);
			},
			error: function () {
				Swal.fire('Gagal', 'Terjadi kesalahan saat memuat detail siswa.', 'error');
			}
		});
	}

	function renderHeader(s, r) {
		let jumlah = r && r.jumlah_sesi ? r.jumlah_sesi : 0;
		$('#header-siswa').html(`
			<div class="d-flex align-items-center justify-content-between gap-2 flex-wrap">
				<div class="d-flex align-items-center gap-2">
					<a href="<?= base_url('latihan_soal/analisa_kelas'); ?>" class="back-round" title="Kembali"><i
                        class="ti ti-arrow-left"></i></a>
					<div>
						<h4 class="student-name-title">${escapeHtml(s.nama_siswa)}</h4>
						<div class="student-subtitle">${jumlah} hasil ujian · ${escapeHtml(s.kelas_filter || '-')} · ${escapeHtml(s.tahun_ajaran || '-')}</div>
					</div>
				</div>
			</div>
		`);
	}

	function renderMapelOptions(rows, aktif) {
		let html = '';

		if (!rows || rows.length == 0) {
			html = '<option value="">Belum ada mata pelajaran</option>';
			$('#filter-mapel-detail').html(html).prop('disabled', true);
			return;
		}

		rows.forEach(function (row) {
			let selected = String(row.id_mata_pelajaran) == String(aktif) ? 'selected' : '';
			html += `<option value="${escapeHtml(row.id_mata_pelajaran)}" ${selected}>${escapeHtml(row.nama_mata_pelajaran || '-')}</option>`;
		});

		$('#filter-mapel-detail').html(html).prop('disabled', false);
	}

	function renderRingkasan(r) {
		r = r || {};
		let html = '';
		let cards = [
			{
				label: 'Rata-rata Keseluruhan',
				value: r.rata || '-',
				icon: '◎'
			}
		];

		if (r.mapel_aktif) {
			cards.push({
				label: 'Rata-rata ' + shortMapelName(r.mapel_aktif.nama_mata_pelajaran),
				value: r.mapel_aktif.rata_format || '-',
				icon: '◎'
			});
		}

		cards.forEach(function (card, index) {
			html += `
				<div class="summary-card ${summaryColor(index)}">
					<div class="summary-icon">${card.icon}</div>
					<div class="summary-content">
						<div class="summary-label" title="${escapeHtml(card.label)}">${escapeHtml(card.label)}</div>
						<div class="summary-value">${escapeHtml(card.value)}</div>
					</div>
				</div>
			`;
		});

		$('#ringkasan-siswa').html(html);
	}

	function renderRiwayat(rows, aktif) {
		let html = '';
		if (!rows || rows.length == 0) {
			html = '<div class="empty-state">Belum ada riwayat pengerjaan.</div>';
		} else {
			rows.forEach(function (row) {
				let activeClass = String(row.id) == String(aktif) ? 'active' : '';
				html += `
					<div class="history-item ${activeClass}" onclick="detailSiswa('${row.id}')">
						<div class="d-flex justify-content-between gap-2">
							<div class="min-w-0">
								<h5 class="history-title">${escapeHtml(row.nama_sesi)}</h5>
								<div class="history-meta">${escapeHtml(row.nama_mata_pelajaran || '-')}</div>
								<div class="history-meta">${escapeHtml(row.tanggal || '-')}</div>
							</div>
							<div class="history-score">${escapeHtml(row.nilai_format || '-')}</div>
						</div>
					</div>
				`;
			});
		}
		$('#riwayat-pengerjaan').html(html);
	}
function statusPengerjaanText(d) {
	if (!d) {
		return '-';
	}

	if (d.status_pengerjaan == 'Proses') {
		return 'Sedang mengerjakan';
	}

	if (parseInt(d.reset_jawaban || 0) > 0) {
		return 'Jawaban pernah dihapus karena keluar halaman';
	}

	if (d.status_pengerjaan == 'Waktu Habis') {
		return 'Selesai karena timer habis';
	}

	if (d.status_pengerjaan == 'Selesai') {
		return 'Selesai';
	}
	return d.status_pengerjaan || '-';
}

	function renderDetailSesi(d) {
		if (!d) {
			$('#detail-sesi').html('<div class="empty-state">Pilih salah satu riwayat untuk melihat detail sesi.</div>');
			return;
		}

		let benar = d.jumlah_benar || 0;
		let total = (parseInt(d.jumlah_benar || 0) + parseInt(d.jumlah_salah || 0) + parseInt(d.jumlah_kosong || 0));
		let benarText = total > 0 ? `${benar}/${total} benar` : `${benar} benar`;
let statusText = statusPengerjaanText(d);
		$('#detail-sesi').html(`
			<div class="session-head">
				<div>
					<h4 class="session-title">${escapeHtml(d.nama_sesi || '-')}</h4>
					<div class="session-mapel">${escapeHtml(d.nama_mata_pelajaran || '-')}</div>
				</div>
				<div class="session-score">
					${escapeHtml(d.nilai_format || '-')}
					<small>${escapeHtml(benarText)}</small>
				</div>
			</div>

			<div class="session-info">
				<span class="info-chip">Durasi: ${escapeHtml(d.durasi_format || '-')}</span>
				<span class="info-chip">Jenis: ${escapeHtml(d.jenis_pengerjaan || '-')}</span>
				<span class="info-chip">Kategori: ${escapeHtml(d.nama_kategori_soal || '-')}</span>
				<span class="info-chip">Status Pengerjaan: ${escapeHtml(statusText)}</span>
			</div>
		`);
	}

	function topicList(rows, type) {
		if (!rows || rows.length == 0) {
			return '<div class="empty-state">Tidak ada data.</div>';
		}

		let html = '';
		rows.forEach(function (row) {
			let cls = colorByPercent(row.persen_format || row.persen || 0);
			html += `
				<div class="topic-row">
					<div class="topic-name">${escapeHtml(row.nama_materi || '-')}</div>
					<div class="d-flex align-items-center gap-2">
						<span class="topic-count">${escapeHtml(row.jumlah_benar || 0)}/${escapeHtml(row.total_soal || 0)}</span>
						<span class="topic-pill pill-${cls}">${escapeHtml(row.persen_format || '-')}</span>
					</div>
				</div>
			`;
		});
		return html;
	}

	function allTopicList(rows) {
		if (!rows || rows.length == 0) {
			return '<div class="empty-state">Tidak ada data semua topik.</div>';
		}

		let html = '';
		rows.forEach(function (row) {
			let persen = percentNumber(row.persen_format || row.persen || 0);
			let cls = colorByPercent(persen);
			html += `
				<div class="all-topic-row">
					<div class="all-topic-name">${escapeHtml(row.nama_materi || '-')}</div>
					<div class="progress-mini ${cls}"><span style="width:${Math.max(0, Math.min(100, persen))}%"></span></div>
					<div class="text-end fw-bold ${cls == 'good' ? 'text-success' : (cls == 'mid' ? 'text-warning' : 'text-danger')}">${escapeHtml(row.persen_format || '-')}</div>
				</div>
			`;
		});
		return html;
	}

	function renderMateri(data) {
		data = data || { kekuatan: [], kelemahan: [], semua: [] };
		$('#analisa-materi-siswa').html(`
			<div class="topic-box success">
				<div class="topic-box-title">↗ Kekuatan (Topik Dikuasai)</div>
				${topicList(data.kekuatan, 'success')}
			</div>

			<div class="topic-box warning">
				<div class="topic-box-title">↘ Kelemahan (Perlu Ditingkatkan)</div>
				${topicList(data.kelemahan, 'warning')}
			</div>

			<h4 class="panel-title">Semua Topik</h4>
			${allTopicList(data.semua)}
		`);
	}

	function statusJawabanInfo(status) {
		let textStatus = String(status || '-');
		let normalized = textStatus.toLowerCase();

		if (normalized.indexOf('sebagian') !== -1) {
			return {
				text: textStatus,
				className: 'sebagian'
			};
		}

		if (normalized.indexOf('benar') !== -1) {
			return {
				text: textStatus,
				className: 'benar'
			};
		}

		if (normalized.indexOf('salah') !== -1) {
			return {
				text: textStatus,
				className: 'salah'
			};
		}

		return {
			text: textStatus,
			className: 'salah'
		};
	}

	function parseNilaiPreview(value) {
		let text = String(value ?? '0').replace('%', '').trim();

		if (text.indexOf(',') !== -1) {
			text = text.replace(/\./g, '').replace(',', '.');
		} else {
			text = text.replace(/[^0-9.-]/g, '');
		}

		let n = parseFloat(text);
		return isNaN(n) ? 0 : n;
	}

	function formatNilaiPreview(value) {
		let n = parseFloat(value);
		if (isNaN(n)) {
			return '-';
		}

		return n.toLocaleString('id-ID', {
			maximumFractionDigits: 2
		});
	}

	function getTotalNilaiPreview(rows) {
		if (currentDetail && currentDetail.detail_sesi && currentDetail.detail_sesi.nilai_format) {
			return currentDetail.detail_sesi.nilai_format;
		}

		let total = 0;
		(rows || []).forEach(function (row) {
			total += parseNilaiPreview(row.nilai_format || row.nilai || 0);
		});

		return formatNilaiPreview(total);
	}

	function showPreviewModal() {
		if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
			let modal = new bootstrap.Modal(document.getElementById('modal-preview-jawaban'));
			modal.show();
		} else {
			$('#modal-preview-jawaban').modal('show');
		}
	}

	function renderPreview(rows) {
		let html = '';
		let totalNilai = getTotalNilaiPreview(rows);

		if (!rows || rows.length == 0) {
			html = '<div class="empty-state">Belum ada preview jawaban.</div>';
			totalNilai = '-';
			$('#btn-preview').prop('disabled', true);
		} else {
			$('#btn-preview').prop('disabled', false);

			rows.forEach(function (row, index) {
				let gambarUrl = row.gambar_soal || '';
				if (gambarUrl !== '' && !/^https?:\/\//i.test(gambarUrl)) {
					gambarUrl = '<?= base_url(); ?>' + gambarUrl;
				}

				let gambar = gambarUrl ? `
					<div class="preview-section">
						<div class="preview-label">Gambar Soal</div>
						<img src="${escapeHtml(gambarUrl)}" class="img-fluid rounded border" style="max-height:260px;">
					</div>
				` : '';

				let statusInfo = statusJawabanInfo(row.status_jawaban);
				let nomor = row.nomor_soal || (index + 1);

				html += `
					<div class="preview-question-card">
						<div class="preview-question-head">
							<div class="d-flex gap-2">
								<div class="preview-no">${escapeHtml(nomor)}</div>
								<div>
									<h5 class="preview-title">Soal ${escapeHtml(nomor)}</h5>
									<div class="preview-subtitle">${escapeHtml(row.nama_materi || '-')}</div>
								</div>
							</div>
							<span class="preview-badge ${statusInfo.className}">${escapeHtml(statusInfo.text)}</span>
						</div>

						<div class="preview-section">
							<div class="preview-label">Pertanyaan</div>
							<div class="preview-text">${escapeHtml(row.pertanyaan || '-')}</div>
						</div>

						${gambar}

						<div class="preview-answer-grid">
							<div class="preview-answer-box student-answer">
								<div class="preview-label">Jawaban Siswa</div>
								<div class="preview-text">${escapeHtml(row.jawaban_siswa_text || '-')}</div>
							</div>
							<div class="preview-answer-box correct-answer">
								<div class="preview-label">Kunci Jawaban</div>
								<div class="preview-text">${escapeHtml(row.jawaban_benar_text || '-')}</div>
							</div>
						</div>

						${row.pembahasan ? `
							<div class="preview-section">
								<div class="preview-label">Pembahasan</div>
								<div class="preview-text">${escapeHtml(row.pembahasan)}</div>
							</div>
						` : ''}

						<div class="preview-score-row">
							<div>
								<span class="preview-badge ${statusInfo.className}">${escapeHtml(statusInfo.text)}</span>
							</div>
							<div class="preview-score">Nilai: ${escapeHtml(row.nilai_format || '-')}</div>
						</div>
					</div>
				`;
			});
		}

		$('#preview-jawaban-modal-body').html(html);
		$('#preview-total-nilai').text(totalNilai || '-');

		let subtitle = 'Detail soal, jawaban siswa, kunci jawaban, status, dan nilai.';
		if (currentDetail && currentDetail.detail_sesi) {
			subtitle = `${currentDetail.detail_sesi.nama_sesi || '-'} · ${currentDetail.detail_sesi.nama_mata_pelajaran || '-'} · ${rows ? rows.length : 0} soal`;
		}
		$('#preview-modal-subtitle').text(subtitle);
	}
</script>
