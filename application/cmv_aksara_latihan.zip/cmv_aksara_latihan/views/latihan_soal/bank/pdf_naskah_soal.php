<?php
$naskah = isset($naskah) ? $naskah : [];
$soal = isset($soal) ? $soal : [];

function h_naskah($text)
{
    return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8');
}

function nomor_label_naskah($index)
{
    $index = (int) $index;
    $label = '';
    do {
        $label = chr(65 + ($index % 26)) . $label;
        $index = floor($index / 26) - 1;
    } while ($index >= 0);
    return $label;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?= h_naskah($naskah['nama_naskah_soal'] ?? 'Naskah Soal'); ?></title>
    <style>
        * { box-sizing: border-box; }
        body { font-family: Arial, Helvetica, sans-serif; color: #222; margin: 0; background: #f3f4f6; }
        .toolbar { position: sticky; top: 0; z-index: 2; padding: 12px 20px; background: #111827; color: #fff; display: flex; justify-content: space-between; align-items: center; }
        .toolbar button { border: 0; border-radius: 6px; padding: 8px 14px; cursor: pointer; font-weight: 700; }
        .page { width: 210mm; min-height: 297mm; margin: 16px auto; padding: 18mm; background: #fff; }
        .kop { border: 2px solid #111; padding: 12px; margin-bottom: 12px; text-align: center; }
        .kop h1 { margin: 0; font-size: 22px; letter-spacing: .5px; }
        .kop p { margin: 4px 0 0; font-size: 12px; }
        .title { text-align: center; margin: 16px 0 14px; }
        .title h2 { margin: 0; font-size: 18px; text-decoration: underline; }
        .meta { width: 100%; border-collapse: collapse; margin-bottom: 18px; font-size: 13px; }
        .meta td { padding: 3px 4px; vertical-align: top; }
        .soal-item { page-break-inside: avoid; margin-bottom: 16px; }
        .soal-head { display: flex; gap: 10px; align-items: flex-start; font-size: 13px; margin-bottom: 6px; color: #444; }
        .nomor { font-weight: bold; min-width: 32px; }
        .pertanyaan { font-size: 14px; line-height: 1.5; margin-bottom: 8px; }
        .gambar-soal { max-width: 100%; max-height: 230px; display: block; margin: 8px 0; border: 1px solid #ddd; padding: 4px; }
        .opsi { margin-left: 34px; font-size: 14px; }
        .opsi-row { display: flex; gap: 8px; margin-bottom: 6px; align-items: flex-start; line-height: 1.45; }
        .opsi-label { min-width: 24px; font-weight: bold; }
        .pernyataan-label { min-width: 88px; font-weight: bold; }
        .jawab-bs { white-space: nowrap; margin-left: 10px; }
        .footer-note { margin-top: 26px; font-size: 12px; color: #666; text-align: center; }
        @media print {
            body { background: #fff; }
            .toolbar { display: none; }
            .page { width: auto; min-height: auto; margin: 0; padding: 0; box-shadow: none; }
            @page { size: A4; margin: 14mm; }
        }
    </style>
</head>
<body>
    <div class="toolbar">
        <div><?= h_naskah($naskah['nama_naskah_soal'] ?? 'Naskah Soal'); ?></div>
        <button type="button" onclick="window.print()">Print / Simpan PDF</button>
    </div>

    <div class="page">
        <div class="kop">
            <h1>KOP BIMBEL AKSARA</h1>
            <p>Alamat: ....................................................................................................................</p>
            <p>Telepon: ........................................ &nbsp; Email: ....................................................</p>
        </div>

        <div class="title">
            <h2>NASKAH SOAL</h2>
        </div>

        <table class="meta">
            <tr>
                <td style="width: 150px;">Nama Naskah</td><td style="width: 8px;">:</td><td><?= h_naskah($naskah['nama_naskah_soal'] ?? '-'); ?></td>
                <td style="width: 130px;">Jumlah Soal</td><td style="width: 8px;">:</td><td><?= (int) ($naskah['jumlah_soal'] ?? 0); ?> soal</td>
            </tr>
            <tr>
                <td>Mata Pelajaran</td><td>:</td><td><?= h_naskah($naskah['nama_mata_pelajaran'] ?? '-'); ?></td>
                <td>Kategori</td><td>:</td><td><?= h_naskah($naskah['nama_kategori_soal'] ?? '-'); ?></td>
            </tr>
            <tr>
                <td>Nama Siswa</td><td>:</td><td>..............................................................</td>
                <td>Kelas</td><td>:</td><td>................................</td>
            </tr>
        </table>

        <?php if (empty($soal)): ?>
            <p>Belum ada soal aktif pada naskah ini.</p>
        <?php else: ?>
            <?php foreach ($soal as $row): ?>
                <div class="soal-item">
                    <div class="soal-head">
                        <div class="nomor">No. <?= h_naskah($row['nomor_soal'] ?? '-'); ?></div>
                        <div>
                            <b>Materi:</b> <?= h_naskah($row['nama_materi'] ?? '-'); ?> &nbsp; | &nbsp;
                            <b>Tipe:</b> <?= h_naskah($row['tipe_soal_label'] ?? '-'); ?> &nbsp; | &nbsp;
                            <b>Bobot:</b> <?= h_naskah($row['bobot_nilai'] ?? '-'); ?>
                        </div>
                    </div>
                    <div class="pertanyaan">
                        <?= $row['pertanyaan'] ?? '-'; ?>
                    </div>
                    <?php if (!empty($row['gambar_soal'])): ?>
                        <img src="<?= h_naskah($row['gambar_soal']); ?>" class="gambar-soal" alt="Gambar Soal">
                    <?php endif; ?>

                    <div class="opsi">
                        <?php if (($row['tipe_soal'] ?? '') === 'benar_salah'): ?>
                            <?php foreach (($row['jawaban'] ?? []) as $idx => $jawab): ?>
                                <div class="opsi-row">
                                    <span class="pernyataan-label">Pernyataan <?= $idx + 1; ?></span>
                                    <span><?= h_naskah($jawab['isi_jawaban'] ?? '-'); ?></span>
                                    <span class="jawab-bs">( ) Benar &nbsp;&nbsp; ( ) Salah</span>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <?php foreach (($row['jawaban'] ?? []) as $idx => $jawab): ?>
                                <div class="opsi-row">
                                    <span class="opsi-label"><?= h_naskah($jawab['label_jawaban'] ?? nomor_label_naskah($idx)); ?>.</span>
                                    <span><?= h_naskah($jawab['isi_jawaban'] ?? '-'); ?></span>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
